 <?php
$koneksi=mysqli_connect('localhost','root','','ujikom');
//$koneksi=mysqli_connect("localhost","root","","ujikom");
?> 



