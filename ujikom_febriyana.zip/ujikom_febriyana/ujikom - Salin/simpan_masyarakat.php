<?php
include 'koneksi.php';
$nik=$_POST['nik'];
$nama=$_POST['nama'];
$user=$_POST['username'];
$pas=$_POST['password'];
$telp=$_POST['telp'];

$sql = mysqli_query($koneksi, "insert into masyarakat values('$nik', '$nama', '$user', '$pas', '$telp')");
if ($sql)
{
    ?>
    <script type="text/javascript">
        alert ('Data berhasil disimpan, Silahkan gunakan untuk login');
        window.location="index.php";
    </script>
<?php
}
?>